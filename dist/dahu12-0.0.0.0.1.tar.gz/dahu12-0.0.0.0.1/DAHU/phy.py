## Module : Partie Physique ##

import main
import erreurs as er

## Plusieurs branches :
# -elec
# -thermo
# ...##

def extractp(chemin):
    df = main.importdata(chemin)

def diagenthal() :
    pass