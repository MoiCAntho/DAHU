

class Entite():
    def __init__(self):
        pass

class Mol(Entite):

    def __init__(self):
        pass

class Compl(Entite):

    def __init__(self):
        pass



regles_correspondances = []

def nom_orga(mol) :
    pass

def mol_orga(nom) :
    pass