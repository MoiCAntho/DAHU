## Module : Partie Physique ##

import main
import erreurs as er

## Plusieurs branches :
# -elec
# -thermo
# ...##

def extractp(chemin):
    df = main.importdata(chemin)

def diagenthal() :
    pass

## Astronomie
class OCel : #Définition d'un objet céleste
    def __init__(self) -> None:
        pass


