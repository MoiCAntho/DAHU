# DAHU.py
## _Package scientifique python_
***
## Auteurs : 
- LOUVAT SEGURA Anthony
- CHEMINOT Virgile

## Remerciements
Nous souhaitons dans un premier temps remercier tous particulièrement notre professeur de mathématiques : Bernard Parisse, sans qui le projet ne serait pas là où il en est actuellement (faites un tour sur sa page personnel de l'université joseph fourrier).
Il a nous permis d'utiliser sa création : le CAS Giac, sur qui est basé toute la gestion d'expression algébrique du package.

DAHU est une librairie python destiné aux étudiants et scientifiques, qui contient beaucoup de fonction leurs étant utile.

Installation provisoire : https://pypi.org/project/DAHU12/
