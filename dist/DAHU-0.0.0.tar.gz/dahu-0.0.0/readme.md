# DAHU.py
***

Auteurs : 
    - LOUVAT SEGURA Anthony
    - CHEMINOT Virgile

Nous souhaitons dans un premier temps remercier tous particulièrement notre professeur de mathématiques : Bernard Parisse, sans qui le projet ne serait pas là où il en est actuellement (faites un tour sur sa page personnel de l'université joseph fourrier).
Il a nous permis d'utiliser sa création : le CAS Giac, sur qui est basé toute la gestion d'expression du module.

DAHU est une librairie python destiné aux étudiants et scientifiques, qui contient beaucoup de fonction leurs étant utile.
