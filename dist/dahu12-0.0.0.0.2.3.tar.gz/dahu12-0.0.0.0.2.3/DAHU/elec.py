class circuit :
    def __init__(self) :
        pass


class composant :
    def __init__(self) :
        pass


def SPICE() : #Convertit le circuit en format SPICE dans fichier .txt
    pass

